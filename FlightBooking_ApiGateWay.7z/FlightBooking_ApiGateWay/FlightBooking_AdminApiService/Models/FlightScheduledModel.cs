﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Models
{
    public class FlightScheduledModel
    {
        public string FlightNumber { get; set; }
        //public string FlightName { get; set; }
        public int FlightId { get; set; }
        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        //public List<ScheduledDaysModel> ScheduledDaysModel { get; set; }

        public string ScheduledDays { get; set; }
        public string Instrumentused { get; set; }
        public string TotalNonBusinessClassSeats { get; set; }
        public string TotalBusinessClassSeats { get; set; }
        public decimal TicketCost { get; set; }
        public string MealId { get; set; }
        public int discountid { get; set; }
        //public int CreatedById { get; set; }

    }
}
