﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Models
{
    public class DiscountModel
    {
        public string Couper { get; set; }
        public int DiscountValue { get; set; }
        public int CreatedById { get; set; }
    }
}
