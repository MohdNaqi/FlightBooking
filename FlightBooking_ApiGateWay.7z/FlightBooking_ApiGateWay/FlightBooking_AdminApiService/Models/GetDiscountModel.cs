﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Models
{
    public class GetDiscountModel
    {
        public int DiscountId { get; set; }
        public string CouponCode { get; set; }
        public int? DiscountValue { get; set; }
        public bool IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
