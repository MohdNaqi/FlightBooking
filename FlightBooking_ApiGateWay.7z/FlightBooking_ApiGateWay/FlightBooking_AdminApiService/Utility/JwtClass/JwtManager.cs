﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.JwtClass
{
    public class JwtManager
    {

        //private readonly JwtIssuerOptions _jwtOptions;
        //private readonly JsonSerializerSettings _serializerSettings;
        //public JwtManager(IOptions<JwtIssuerOptions> jwtOptions)
        //{
        //    _jwtOptions = jwtOptions.Value;
        //    //ThrowIfInvalidOptions(_jwtOptions);
        //    _serializerSettings = new JsonSerializerSettings
        //    {
        //        Formatting = Formatting.Indented
        //    };
        //}
        //public Task<ClaimsIdentity> GetClaimsIdentity(string UserName)
        //{


        //    //return Task.FromResult(new ClaimsIdentity(new GenericIdentity(UserName, "Token")));
        //    return Task.FromResult(new ClaimsIdentity(new GenericIdentity(UserName, "Token"), new[] { new Claim("DisneyCharacter", "IAmMickey") }));

        //}

        //public async Task<string> GenerateToken(string userName)
        //{


        //    string token = "";
        //    var identity = await GetClaimsIdentity(userName);
        //    if (identity == null)
        //        token = null;
        //    else
        //    {
        //        var claims = new[]
        //        {
        //         new Claim(JwtRegisteredClaimNames.Sub, userName),
        //         new Claim(JwtRegisteredClaimNames.Jti, await _jwtOptions.JtiGenerator()),
        //         new Claim(JwtRegisteredClaimNames.Iat,
        //         ToUnixEpochDate(_jwtOptions.IssuedAt).ToString(),
        //         ClaimValueTypes.Integer64),
        //         identity.FindFirst("DisneyCharacter")
        //         };

        //        // Create the JWT security token and encode it.
        //        var jwt = new JwtSecurityToken(
        //            issuer: _jwtOptions.Issuer,
        //            audience: _jwtOptions.Audience,
        //            claims: claims,
        //            notBefore: _jwtOptions.NotBefore,
        //            expires: DateTime.UtcNow.AddMinutes(Convert.ToInt32(60*24)),
        //            signingCredentials: _jwtOptions.SigningCredentials);

        //        var encodedJwt = new JwtSecurityTokenHandler().WriteToken(jwt);
        //        token = encodedJwt;
        //    }
        //    return token;
        //}


        //public static void ThrowIfInvalidOptions(JwtIssuerOptions options)
        //{
        //    if (options == null) throw new ArgumentNullException(nameof(options));

        //    //if (options.ValidFor <= TimeSpan.Zero)
        //    //{
        //    //    throw new ArgumentException("Must be a non-zero TimeSpan.", nameof(JwtIssuerOptions.ValidFor));
        //    //}

        //    if (options.SigningCredentials == null)
        //    {
        //        throw new ArgumentNullException(nameof(JwtIssuerOptions.SigningCredentials));
        //    }

        //    if (options.JtiGenerator == null)
        //    {
        //        throw new ArgumentNullException(nameof(JwtIssuerOptions.JtiGenerator));
        //    }
        //}
        private static long ToUnixEpochDate(DateTime date) => (long)Math.Round((date.ToUniversalTime() - new DateTimeOffset(1970, 1, 1, 0, 0, 0, TimeSpan.Zero)).TotalSeconds);
    }
}
