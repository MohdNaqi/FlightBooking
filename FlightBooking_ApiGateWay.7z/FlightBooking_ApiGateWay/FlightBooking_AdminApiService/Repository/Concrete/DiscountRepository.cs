﻿using FlightBooking_AdminApiService.Models;
using FlightBooking_AdminApiService.Repository.Abstract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Repository.Concrete
{
    public class DiscountRepository : Repositories, IDiscountRepository
    {
        public async Task<int> AddDiscount(DiscountModel discountModel)
        {

            var objDiscount = new FlightBooking_AdminApiService.Entity.Discount()
            {
               CouponCode = discountModel.Couper,
               DiscountValue = discountModel.DiscountValue,
                CreatedBy = discountModel.CreatedById,
                CreatedDate = DateTime.UtcNow,
                IsActive = true

            };
            flightBookingContext.Discount.Add(objDiscount);
            flightBookingContext.SaveChanges();
            int id = objDiscount.DiscountId;
            return await Task.FromResult(id);
        }

        public async Task<List<GetDiscountModel>> GetDiscount()
        {
            List<GetDiscountModel> _list = (from item in flightBookingContext.Discount
                                               //where item.IsActive == true
                                               select new GetDiscountModel()
                                               {
                                                   DiscountId = item.DiscountId,
                                                 CouponCode = item.CouponCode,
                                                 DiscountValue = item.DiscountValue,
                                                 CreatedBy = item.CreatedBy,
                                                 CreatedDate = item.CreatedDate,
                                               }).ToList();
            return await Task.FromResult(_list);

        }

        public async Task<int> DeleteDiscount(int DiscountId)
        {
            int result = 0;

            var itemToRemove = flightBookingContext.Discount.Where(x => x.DiscountId == DiscountId).FirstOrDefault();//returns a single item.

            if (itemToRemove != null)
            {
                itemToRemove.IsActive = false;
                flightBookingContext.SaveChanges();
            }
            return await Task.FromResult(result);
        }
    }
}
