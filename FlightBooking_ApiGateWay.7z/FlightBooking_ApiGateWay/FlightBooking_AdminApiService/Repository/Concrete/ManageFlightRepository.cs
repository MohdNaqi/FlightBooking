﻿using FlightBooking_AdminApiService.Entity;
using FlightBooking_AdminApiService.Models;
using FlightBooking_AdminApiService.Repository.Abstract;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Repository.Concrete
{
    public class ManageFlightRepository : Repositories, IManageFlightRepository
    {
        public async Task<int> AddFlight(AirlineModel objAirline)
        {

            var objAddFlight = new FlightBooking_AdminApiService.Entity.Airline()
            {
                AirlineNumber = objAirline.AirlineNumber,
                AirlineName = objAirline.AirlineName,
                CreatedById = '1',
                CreatedDate = DateTime.UtcNow,
                IsActive = true 

            };
            flightBookingContext.Airline.Add(objAddFlight);
            flightBookingContext.SaveChanges();
            int id = objAddFlight.AirlineId;
            return await Task.FromResult(id);
        }

        public async Task<List<GetAirLineModel>> GetAirPort()
        {
            flightBookingContext.Database.OpenConnection();
            DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "GetAllAirLine";
            cmd.CommandType = CommandType.StoredProcedure;
            List<GetAirLineModel> lstAirline = new List<GetAirLineModel>();
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                GetAirLineModel obj = new GetAirLineModel();
                obj.AirLineId = Convert.ToInt32(reader["AirlineID"]);
                obj.AirLineNumber = Convert.ToString(reader["AirlineNumber"]);
                obj.AirLineName = Convert.ToString(reader["AirlineName"]);
                obj.IsActive = Convert.ToBoolean(reader["IsActive"]);

                lstAirline.Add(obj);

            }
            flightBookingContext.Database.CloseConnection();
            return await Task.FromResult(lstAirline);

        }

        public async Task<int> BlockFlight(int flightId)
        {
            int result = 0;

            var itemToRemove = flightBookingContext.Airline.Where(x => x.AirlineId == flightId).FirstOrDefault();//returns a single item.

            if (itemToRemove != null)
            {
                result = itemToRemove.AirlineId;
                itemToRemove.IsActive = false;
                itemToRemove.ModifedDate = DateTime.UtcNow;
                flightBookingContext.SaveChanges();
            }
            return await Task.FromResult(result);
        }

        public async Task<bool> IsFlightExist(string flightNumber, string flightName)
        {
            bool result = false;

            var storeInfo = flightBookingContext.Airline.Where(s => s.AirlineNumber == flightNumber && s.AirlineName == flightName && s.IsActive == true).FirstOrDefault();
            if (storeInfo != null)
            {
                result = true;
            }

            return await Task.FromResult(result);
        }

        public async Task<List<MealModel>> GetMeal()
        {
            var lstMeal = (from r in flightBookingContext.Meal
                           select new MealModel
                           {
                               MealId = r.MealId,
                               MealName = r.MealName
                           }).ToList();
            return await Task.FromResult(lstMeal);
        }


        public async Task<ResponseMessageModel> AddFlightScheduled(FlightScheduledModel objFlightScheduledModel)
        {
            ResponseMessageModel _responseMessageModel = new ResponseMessageModel();
            //Get Master Event Name and Id from Master Table
            var isFlightExist = (from me in flightBookingContext.Airline
                                 where me.AirlineNumber == objFlightScheduledModel.FlightNumber && me.AirlineId==objFlightScheduledModel.FlightId && me.IsActive == true
                                 select me).FirstOrDefault();
            if (isFlightExist == null)
            {
                _responseMessageModel.id = 0;
                _responseMessageModel.responsemessage = "Flight Not Exist";
                return await Task.FromResult(_responseMessageModel);
            }
            else
            {
                var objflightSchedureReturntype = new FlightBooking_AdminApiService.Entity.FlightSchedule()
                {
                    AirlineId = isFlightExist.AirlineId,
                    FromPlace = objFlightScheduledModel.FromPlace,
                    ToPlace = objFlightScheduledModel.ToPlace,
                    StartDateTime = objFlightScheduledModel.StartDateTime,
                    EndDateTime = objFlightScheduledModel.EndDateTime,
                    ScheduledDayId = objFlightScheduledModel.ScheduledDays,
                    InstrumentUsed = objFlightScheduledModel.Instrumentused,
                    NonBusinessClassSeat = objFlightScheduledModel.TotalNonBusinessClassSeats,
                    BusinessClassSeats = objFlightScheduledModel.TotalBusinessClassSeats,
                    TicketCost = objFlightScheduledModel.TicketCost,
                    MealId = objFlightScheduledModel.MealId,
                    DiscountId = objFlightScheduledModel.discountid,
                    CreatedDate = DateTime.UtcNow,
                    IsActive = true

                };
                flightBookingContext.FlightSchedule.Add(objflightSchedureReturntype);
                flightBookingContext.SaveChanges();
                int id = objflightSchedureReturntype.FlightScheduledId;
                _responseMessageModel.id = id;
                _responseMessageModel.responsemessage = "Success";
                return await Task.FromResult(_responseMessageModel);
            }
        }
    }
}
