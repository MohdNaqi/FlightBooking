﻿using FlightBooking_AdminApiService.Models;
using FlightBooking_AdminApiService.Repository.Abstract;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_AdminApiService.Controllers
{

    [EnableCors("CorsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class ManageFlightController : ControllerBase
    {
        private readonly IRepositoryCollection manageFlightCollection;
        public IConfiguration iConfiguration { get; }

        public ManageFlightController(IRepositoryCollection _IServiceCollection, IConfiguration configuration)
        {
            manageFlightCollection = _IServiceCollection;
            iConfiguration = configuration;
        }

       
        [Route("AddFlight")]
        [HttpPost]
        public async Task<IActionResult> AddFlight([FromBody] AirlineModel objAirline)
        {
            try
            {
                var objAddFlightReturnType = await manageFlightCollection.ManageFlightRepository.AddFlight(objAirline);
                return Ok(objAddFlightReturnType);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("BlockFlight/{flightId}")]
        public async Task<IActionResult> BlockFlight([FromRoute]int flightId)
        {

            try
            {
                var objBlockFlightReturnType =await manageFlightCollection.ManageFlightRepository.BlockFlight(flightId);
                return Ok(objBlockFlightReturnType);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //[EnableCors("AllowOrigin")]
        [Route("GetFlight")]
        [HttpGet]
        public async Task<IActionResult> GetAllFlight()
        {
            try
            {
                var objGetAllFlight = await manageFlightCollection.ManageFlightRepository.GetAirPort();
                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //[Route("IsFlightExist")]
        //[HttpPost]
        //public async Task<IActionResult> IsFlightExist(string flightnumber, string flightName)
        //{
        //    try
        //    {
        //        var objIsFlightExist = await manageFlightCollection.ManageFlightRepository.IsFlightExist(flightnumber,flightName);
        //        return Ok(objIsFlightExist);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        [Route("GetAllMeal")]
        [HttpGet]
        public async Task<IActionResult> GetAllMeal()
        {
            try
            {
                var objGetAllFlight = await manageFlightCollection.ManageFlightRepository.GetMeal();
                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [Route("AddFlightSchedule")]
        [HttpPost]
        public async Task<ActionResult<ResponseMessageModel>> FlightSchedule([FromBody] FlightScheduledModel objFlightSchedule)
        {
            ResponseMessageModel _responsemessagemodel = new ResponseMessageModel();
            if (ModelState.IsValid)
            {
                try
                {
                    _responsemessagemodel = await manageFlightCollection.ManageFlightRepository.AddFlightScheduled(objFlightSchedule);
                    if (_responsemessagemodel != null)
                    {
                        return Ok(_responsemessagemodel);
                    }
                    else
                    {
                        return NotFound();
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            else
            {
                return BadRequest();
            }
               
        }

    }
}
