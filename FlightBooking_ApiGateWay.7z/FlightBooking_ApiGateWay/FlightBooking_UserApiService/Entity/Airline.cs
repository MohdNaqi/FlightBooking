﻿using System;
using System.Collections.Generic;

namespace FlightBooking_UserApiService.Entity
{
    public partial class Airline
    {
        public int AirlineId { get; set; }
        public string AirlineNumber { get; set; }
        public string AirlineName { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedById { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedById { get; set; }
        public DateTime? ModifedDate { get; set; }
    }
}
