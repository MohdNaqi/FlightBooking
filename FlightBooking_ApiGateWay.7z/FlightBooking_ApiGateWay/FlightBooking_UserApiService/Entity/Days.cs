﻿using System;
using System.Collections.Generic;

namespace FlightBooking_UserApiService.Entity
{
    public partial class Days
    {
        public int Id { get; set; }
        public string Days1 { get; set; }
    }
}
