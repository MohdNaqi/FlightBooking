﻿using System;
using System.Collections.Generic;

namespace FlightBooking_UserApiService.Entity
{
    public partial class FlightSchedule
    {
        public int FlightScheduledId { get; set; }
        public int? AirlineId { get; set; }
        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public DateTime? StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public string ScheduledDayId { get; set; }
        public string InstrumentUsed { get; set; }
        public string NonBusinessClassSeat { get; set; }
        public string BusinessClassSeats { get; set; }
        public decimal? TicketCost { get; set; }
        public string MealId { get; set; }
        public int? CreatedById { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedById { get; set; }
        public DateTime? ModiifiedDate { get; set; }
        public bool? IsActive { get; set; }
        public int? DiscountId { get; set; }
    }
}
