﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Models
{
    public class DiscountModel
    {
        public decimal? price { get; set; }
        public string couper { get; set; }
        public decimal? afterDiscountPrice { get; set; }
        public int? DiscountValue { get; set; }
    }
}
