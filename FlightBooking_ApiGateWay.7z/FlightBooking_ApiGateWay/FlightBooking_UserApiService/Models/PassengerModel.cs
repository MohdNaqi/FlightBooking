﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Models
{
    public class PassengerModel
    {
        public int Passenger_Booking_Id { get; set; }
        public string Passenger_type { get; set; }
        public string Passenger_FirstName { get; set; }
        public string Passenger_LastName { get; set; }
        public string Passenger_Email { get; set; }
        public string Passenger_Gender { get; set; }
    }
}
