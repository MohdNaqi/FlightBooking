﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Models
{
    public class UserAddressModel
    {
        public int UserAccountId { get; set; }
        public string Address1 { get; set; }
        public string Address11 { get; set; }
        public string CityName { get; set; }
        public string StateName { get; set; }
        public string CountryName { get; set; }
        public string ZipCode { get; set; }
        public int CreatedBy { get; set; }
    }
}
