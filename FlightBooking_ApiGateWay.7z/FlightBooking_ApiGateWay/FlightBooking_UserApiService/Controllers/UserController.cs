﻿using FlightBooking_UserApiService.Models;
using FlightBooking_UserApiService.Repository.Abstract;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;

namespace FlightBooking_AdminApiService.Controllers
{
    [ApiController]
    [Route("api/User")]
    public class UserController : Controller
    {
        private readonly IRepositoryCollection UserServiceCollection;
        public IConfiguration Configuration1 { get; }

        public UserController(IRepositoryCollection _IServiceCollection, IConfiguration configuration)
        {
            UserServiceCollection = _IServiceCollection;
            Configuration1 = configuration;
        }

        [Route("login")]
        [HttpPost]
        public async Task<IActionResult> AdminLogin([FromBody] LoginModel objLogin)
        {

            try
            {
                var ObjLoginReturnType = await UserServiceCollection.AccountRepository.UserLogin(objLogin);
                return Ok(ObjLoginReturnType);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("AddUserRegistration")]
        [HttpPost]
        public async Task<ActionResult<ResponseMessageModel>> AddUserRegistration([FromBody] UserRegistrationModel obj)
        {
            ResponseMessageModel _responsemessagemodel = new ResponseMessageModel();
            try
            {
                _responsemessagemodel = await UserServiceCollection.AccountRepository.AddUserRegistration(obj);
                if (_responsemessagemodel != null)
                {
                    return Ok(_responsemessagemodel);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
