﻿    using FlightBooking_UserApiService.Models;
using FlightBooking_UserApiService.Repository.Abstract;
using FlightBooking_UserApiService.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Controllers
{
    //[Microsoft.AspNetCore.Cors.EnableCors("CorsPolicy")]
    [ApiController]
    [Route("api/[controller]")]
    public class FlightController : Controller
    {
        private readonly IRepositoryCollection bookingServiceCollection;
        public IConfiguration Configuration1 { get; }

        public FlightController(IRepositoryCollection _IServiceCollection, IConfiguration configuration)
        {
            bookingServiceCollection = _IServiceCollection;
            Configuration1 = configuration;
        }

        [Route("Search")]
        [HttpPost]
        public async Task<IActionResult> SearchFlight([FromBody] SearchFlightModel objSearchFlight)
        {
            try
            {
                var objSearchFlightReturntype = await bookingServiceCollection.BookingRepository.SearchFlight(objSearchFlight);
                return Ok(objSearchFlightReturntype);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("Booking")]
        [HttpPost]
        public async Task<ActionResult<ResponseMessageModel>> FlightBooking([FromBody] FlightBookingModel flightBooking)
        {
            ResponseMessageModel _responsemessagemodel = new ResponseMessageModel();
            if (ModelState.IsValid)
            {
                try
                {
                    _responsemessagemodel = await bookingServiceCollection.BookingRepository.FlightBooking(flightBooking);
                    if (_responsemessagemodel != null)
                    {
                        return Ok(_responsemessagemodel);
                    }
                    else
                    {
                        return NotFound();
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            else
            {
                return BadRequest();
            }
        }

      
        [HttpGet("BookingFlightCancel/{bookingId}")]
        public async Task<ActionResult<ResponseMessageModel>> BookingFlightCancel([FromRoute] int bookingId)
        {
            ResponseMessageModel _responsemessagemodel = new ResponseMessageModel();
                try
                {
                    _responsemessagemodel = await bookingServiceCollection.BookingRepository.flightBookingCancel(bookingId);
                    if (_responsemessagemodel != null)
                    {
                        return Ok(_responsemessagemodel);
                    }
                    else
                    {
                        return NotFound();
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
        }

     
        [HttpGet("FlightBookingDetails/{PNR_No}")]
        public async Task<ActionResult<List<BookingDetailsViewModel>>> GetFlightBookingDetails([FromRoute] long PNR_No)
        {
            List<BookingDetailsViewModel> bookingDetailsView = new List<BookingDetailsViewModel>();
            try
            {
                bookingDetailsView = await bookingServiceCollection.BookingRepository.BookTicketDetails(PNR_No);
                if (bookingDetailsView != null)
                {
                    return Ok(bookingDetailsView);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


  
        [HttpGet("GetFlightBookingHistory/{emailid}")]
        public async Task<ActionResult<List<BookingDetailsViewModel>>> GetFlightBookingHistory([FromRoute] string emailid)
        {
            List<BookingDetailsViewModel> bookingDetailsView = new List<BookingDetailsViewModel>();
            try
            {
                bookingDetailsView = await bookingServiceCollection.BookingRepository.BookingHistoryDetailsByEmailId(emailid);
                if (bookingDetailsView != null)
                {
                    return Ok(bookingDetailsView);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetActiveFlight")]
        [HttpGet]
        public async Task<IActionResult> GetAllActiveFlight()
        {
            try
            {
                var objGetAllFlight = await bookingServiceCollection.BookingRepository.GetActiveAirLine();
                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetActiveAirlineSchedule")]
        [HttpGet]
        public async Task<IActionResult> GetActiveAirlineSchedule()
        {
            try
            {
                var objGetAllFlight = await bookingServiceCollection.BookingRepository.GetActiveAirlineSchedule();
                return Ok(objGetAllFlight);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("GetBookTicket")]
        [HttpGet]
        public async Task<IActionResult> GetBookTicket()
        {
            try
            {
                var lstbookticket = await bookingServiceCollection.BookingRepository.GetBookTicket();
                return Ok(lstbookticket);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }




        [HttpGet("getDiscountConpen/{flightid}")]
        public async Task<ActionResult<DiscountModel>> GetFlightBookingDetails(int flightid)
        {
            DiscountModel obj = new DiscountModel();
            try
            {
                obj = await bookingServiceCollection.BookingRepository.GetPriceandDiscountCoupen(flightid);
                if (obj != null)
                {
                    return Ok(obj);
                }
                else
                {
                    return Ok(obj);
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
