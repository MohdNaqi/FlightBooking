﻿using FlightBooking_AdminApiService.Utility;
using FlightBooking_UserApiService.Models;
using FlightBooking_UserApiService.Repository.Abstract;
using FlightBooking_UserApiService.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Repository.Concrete
{
    public class BookingRepository : Repositories, IBookingRepository
    {
        public async Task<GetFlightModel> SearchFlight(SearchFlightModel searchFlight)
        {
            try
            {
                GetFlightModel objFlight = new GetFlightModel();
                flightBookingContext.Database.OpenConnection();
                DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
                cmd.CommandText = "sp_SearchFlight";
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter param = new SqlParameter("@Flight", searchFlight.Flight);
                SqlParameter param1 = new SqlParameter("@FromPlace", searchFlight.FromPlace);
                SqlParameter param2 = new SqlParameter("@ToPlace", searchFlight.ToPlace);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(param1);
                cmd.Parameters.Add(param2);
                var reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {

                    while (reader.Read())
                    {
                        objFlight.AirlineID = Convert.ToInt32(reader["AirlineID"]);
                        objFlight.AirlineNumber = Convert.ToString(reader["AirlineNumber"]);
                        objFlight.AirlineName = Convert.ToString(reader["AirlineName"]);
                        objFlight.FromPlace = Convert.ToString(reader["FromPlace"]);
                        objFlight.ToPlace = Convert.ToString(reader["ToPlace"]);
                        objFlight.StartDateTime = Convert.ToString(reader["StartDateTime"]);
                        objFlight.EndDateTime = Convert.ToString(reader["EndDateTime"]);
                        objFlight.TicketCost = Convert.ToString(reader["TicketCost"]);
                        objFlight.BusinessClassSeats = Convert.ToString(reader["BusinessClassSeats"]);
                        objFlight.NonBusinessClassSeat = Convert.ToString(reader["NonBusinessClassSeat"]);
                    }
                    flightBookingContext.Database.CloseConnection();

                }
                else
                {
                    return null;
                }
                return await Task.FromResult(objFlight);
            }
            catch (Exception ex)
            {
                throw;

            }
        }

        public async Task<ResponseMessageModel> FlightBooking(FlightBookingModel flightBooking)
        {
            ResponseMessageModel _responseMessageModel = new ResponseMessageModel();
            Random rand = new Random();
            int RanCode = rand.Next(500000, 1000000);
            var objBooking = new FlightBooking_UserApiService.Entity.Booking()
            {

                // BookingUserId = flightBooking.UserId,
                BookingFlightId = flightBooking.FlightId,
                BookingDate = Convert.ToString(DateTime.Now),
                BookingTotalFare = flightBooking.Booking_total_Fare,
                BookingJourneyDate = flightBooking.Booking_Journey_Date,
                BookingSeatType = flightBooking.Booking_Seat_type,
                BookingSeatNumber = flightBooking.BookingSeatNumber,
                BookingStatus = "1",
                BookingPnr = RanCode,
                IsActive = true,
                //DiscountCoupenName = flightBooking.DiscountCoupenName,
                //WithDiscountPrice = flightBooking.WithDiscountPrice,
                CreatedDate = DateTime.Now
            };
            flightBookingContext.Booking.Add(objBooking);
            flightBookingContext.SaveChanges();
            int bookingId = objBooking.BookingId;
            if (bookingId != 0)
            {
                var objPassenger = new FlightBooking_UserApiService.Entity.Passenger()
                {

                    PassengerBookingId = bookingId,
                    PassengerType = flightBooking.Passenger_type,
                    PassengerFirstName = flightBooking.Passenger_FirstName,
                    PassengerLastName = flightBooking.Passenger_LastName,
                    PassengerEmail = flightBooking.Passenger_Email,
                    PassengerGender = flightBooking.Passenger_Gender,
                    MealId = Convert.ToInt32(flightBooking.mealName),
                    //Createdby = flightBooking.UserId,
                    CreatedDate = DateTime.UtcNow,
                };
                flightBookingContext.Passenger.Add(objPassenger);
                flightBookingContext.SaveChanges();
            }
            _responseMessageModel.id = bookingId;
            _responseMessageModel.responsemessage = "Success";
            return await Task.FromResult(_responseMessageModel);
        }


        public async Task<ResponseMessageModel> flightBookingCancel(int bookingId)
        {
            ResponseMessageModel _responseMessageModel = new ResponseMessageModel();
            int result = 0;

            //var objBookingId = (from item in flightBookingContext.Booking
            //                    join items in flightBookingContext.Passenger
            //                    on item.BookingId equals items.PassengerBookingId
            //                    where item.BookingId == bookingId 
            //                    select item.BookingId).FirstOrDefault();

            if (bookingId != 0)
            {
                var itemToRemove = flightBookingContext.Booking.Where(x => x.BookingId == bookingId).FirstOrDefault();//returns a single item.

                if (itemToRemove != null)
                {
                    result = itemToRemove.BookingId;
                    itemToRemove.IsActive = false;
                    itemToRemove.BookingStatus = "0";
                    itemToRemove.ModifiedDate = DateTime.Now;
                    flightBookingContext.SaveChanges();
                    _responseMessageModel.id = result;
                    _responseMessageModel.responsemessage = "Booking ticket is cancel";
                }
            }
            else
            {
                _responseMessageModel.id = result;
                _responseMessageModel.responsemessage = "Booking email is not found";
            }
            return await Task.FromResult(_responseMessageModel);
        }

        public async Task<List<BookingDetailsViewModel>> BookTicketDetails(long PNR_No)
        {
            flightBookingContext.Database.OpenConnection();
            DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "GetBookingTicketDetailsByPNR";
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter param = new SqlParameter("@PNR_No", PNR_No);
            cmd.Parameters.Add(param);

            List<BookingDetailsViewModel> lstFlightBookingDetails = new List<BookingDetailsViewModel>();
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                BookingDetailsViewModel obj = new BookingDetailsViewModel();
                //obj.BookingByEmail = Convert.ToString(reader["Email"]);
                //obj.BookingByUserName = Convert.ToString(reader["UserName"]);
                //obj.BookingByPhone = Convert.ToString(reader["PhoneNumber"]);

                obj.FlightName = Convert.ToString(reader["AirlineName"]);
                obj.FlightNo = Convert.ToString(reader["AirlineNumber"]);

                obj.Booking_Date = Convert.ToString(reader["Booking_Date"]);
                obj.Booking_total_Fare = Convert.ToString(reader["Booking_total_Fare"]);
                obj.Booking_Journey_Date = Convert.ToString(reader["Booking_Journey_Date"]);
                obj.Booking_Seat_type = Convert.ToString(reader["Booking_Seat_type"]);
                obj.BookingSeatNumber = Convert.ToInt32(reader["Booking_Seat_Number"]);
                if (Convert.ToString(reader["Booking_Status"]) == "1")
                {
                    obj.Booking_Status = "Confirmed";
                }
                else
                {
                    obj.Booking_Status = "Cancelled";
                }
                //obj.Booking_Status = Convert.ToString(reader["Booking_Status"]);
                obj.Booking_PNR = Convert.ToInt64(reader["Booking_PNR"]);

                obj.Passenger_FirstName = Convert.ToString(reader["Passenger_FirstName"]) + ' ' + Convert.ToString(reader["Passenger_LastName"]);

                obj.Passenger_Email = Convert.ToString(reader["Passenger_Email"]);
                obj.Passenger_Gender = Convert.ToString(reader["Passenger_Gender"]);
                obj.Passenger_type = Convert.ToString(reader["Passenger_type"]);
                obj.MealName = Convert.ToString(reader["MealName"]);
                lstFlightBookingDetails.Add(obj);

            }
            flightBookingContext.Database.CloseConnection();
            return await Task.FromResult(lstFlightBookingDetails);
        }

        public async Task<List<BookingDetailsViewModel>> BookingHistoryDetailsByEmailId(string email)
        {
            flightBookingContext.Database.OpenConnection();
            DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "GetBookingHistoryByEmail";
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter param = new SqlParameter("@email", email);
            cmd.Parameters.Add(param);

            List<BookingDetailsViewModel> lstFlightBookingDetails = new List<BookingDetailsViewModel>();
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                BookingDetailsViewModel obj = new BookingDetailsViewModel();

                //obj.BookingByEmail = Convert.ToString(reader["Email"]);
                //obj.BookingByUserName = Convert.ToString(reader["UserName"]);
                //obj.BookingByPhone = Convert.ToString(reader["PhoneNumber"]);

                obj.BookingId = Convert.ToInt32(reader["BookingId"]);
                obj.FlightName = Convert.ToString(reader["AirlineName"]);
                obj.FlightNo = Convert.ToString(reader["AirlineNumber"]);

                obj.Booking_Date = Convert.ToString(reader["Booking_Date"]);
                obj.Booking_total_Fare = Convert.ToString(reader["Booking_total_Fare"]);
                obj.Booking_Journey_Date = Convert.ToString(reader["Booking_Journey_Date"]);
                obj.Booking_Seat_type = Convert.ToString(reader["Booking_Seat_type"]);
                obj.BookingSeatNumber = Convert.ToInt32(reader["Booking_Seat_Number"]);
                if (Convert.ToString(reader["Booking_Status"]) == "1")
                {
                    obj.Booking_Status = "Confirmed";
                }
                else
                {
                    obj.Booking_Status = "Cancelled";
                }
                obj.Booking_PNR = Convert.ToInt64(reader["Booking_PNR"]);

                obj.Passenger_FirstName = Convert.ToString(reader["Passenger_FirstName"]) + ' ' + Convert.ToString(reader["Passenger_LastName"]);
                //obj.Passenger_LastName = Convert.ToString(reader["Passenger_LastName"]);
                obj.Passenger_Email = Convert.ToString(reader["Passenger_Email"]);
                obj.Passenger_Gender = Convert.ToString(reader["Passenger_Gender"]);
                obj.Passenger_type = Convert.ToString(reader["Passenger_type"]);
                obj.MealName = Convert.ToString(reader["MealName"]);
                lstFlightBookingDetails.Add(obj);

            }
            flightBookingContext.Database.CloseConnection();
            return await Task.FromResult(lstFlightBookingDetails);
        }

        public async Task<List<GetAirLineModel>> GetActiveAirLine()
        {
            flightBookingContext.Database.OpenConnection();
            DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "GetActiveAirLine";
            cmd.CommandType = CommandType.StoredProcedure;
            List<GetAirLineModel> lstAirline = new List<GetAirLineModel>();
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                GetAirLineModel obj = new GetAirLineModel();
                obj.AirLineId = Convert.ToInt32(reader["AirlineID"]);
                obj.AirLineNumber = Convert.ToString(reader["AirlineNumber"]);
                obj.AirLineName = Convert.ToString(reader["AirlineName"]);
                obj.IsActive = Convert.ToBoolean(reader["IsActive"]);

                lstAirline.Add(obj);

            }
            flightBookingContext.Database.CloseConnection();
            return await Task.FromResult(lstAirline);

        }

        public async Task<List<GetAirLineModel>> GetActiveAirlineSchedule()
        {
            flightBookingContext.Database.OpenConnection();
            DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "GetAirlineSchedule";
            cmd.CommandType = CommandType.StoredProcedure;
            List<GetAirLineModel> lstAirline = new List<GetAirLineModel>();
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                GetAirLineModel obj = new GetAirLineModel();
                obj.AirLineId = Convert.ToInt32(reader["AirlineID"]);
                obj.AirLineNumber = Convert.ToString(reader["AirlineNumber"]);
                obj.AirLineName = Convert.ToString(reader["AirlineName"]);
                obj.IsActive = Convert.ToBoolean(reader["IsActive"]);

                lstAirline.Add(obj);

            }
            flightBookingContext.Database.CloseConnection();
            return await Task.FromResult(lstAirline);

        }

        public async Task<List<BookingDetailsViewModel>> GetBookTicket()
        {
            flightBookingContext.Database.OpenConnection();
            DbCommand cmd = flightBookingContext.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "GetBookingTicketDetails";
            cmd.CommandType = CommandType.StoredProcedure;
            List<BookingDetailsViewModel> lstTicket = new List<BookingDetailsViewModel>();
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                BookingDetailsViewModel obj = new BookingDetailsViewModel();
                obj.BookingId = Convert.ToInt32(reader["BookingId"]);
                obj.FlightName = Convert.ToString(reader["AirlineName"]);
                obj.FlightNo = Convert.ToString(reader["AirlineNumber"]);

                obj.Booking_Date = Convert.ToString(reader["Booking_Date"]);
                obj.Booking_total_Fare = Convert.ToString(reader["Booking_total_Fare"]);
                obj.Booking_Journey_Date = Convert.ToString(reader["Booking_Journey_Date"]);
                obj.Booking_Seat_type = Convert.ToString(reader["Booking_Seat_type"]);
                obj.BookingSeatNumber = Convert.ToInt32(reader["Booking_Seat_Number"]);
                if (Convert.ToString(reader["Booking_Status"]) == "1")
                {
                    obj.Booking_Status = "Confirmed";
                }
                else
                {
                    obj.Booking_Status = "Cancelled";
                }
                obj.Booking_PNR = Convert.ToInt64(reader["Booking_PNR"]);

                obj.Passenger_FirstName = Convert.ToString(reader["Passenger_FirstName"]) + ' ' + Convert.ToString(reader["Passenger_LastName"]);
                //obj.Passenger_LastName = Convert.ToString(reader["Passenger_LastName"]);
                obj.Passenger_Email = Convert.ToString(reader["Passenger_Email"]);
                obj.Passenger_Gender = Convert.ToString(reader["Passenger_Gender"]);
                obj.Passenger_type = Convert.ToString(reader["Passenger_type"]);
                obj.MealName = Convert.ToString(reader["MealName"]);

                lstTicket.Add(obj);

            }
            flightBookingContext.Database.CloseConnection();
            return await Task.FromResult(lstTicket);

        }


        public async Task<DiscountModel> GetPriceandDiscountCoupen(int flightid)
        {
            DiscountModel model = null;
            List<DiscountModel> _list = (from item in flightBookingContext.FlightSchedule
                                         join items in flightBookingContext.Discount
                                         on item.DiscountId equals items.DiscountId
                                         where item.IsActive == true && item.FlightScheduledId == flightid
                                         select new DiscountModel()
                                         {
                                             price = item.TicketCost,
                                             couper = items.CouponCode,
                                             DiscountValue = items.DiscountValue
                                         }).ToList();
            if (_list.Count != 0)
            {
                foreach (var item in _list)
                {
                    model = new DiscountModel
                    {
                        price = item.price,
                        couper = item.couper,
                        DiscountValue = item.DiscountValue,
                        afterDiscountPrice = item.price - (item.price * item.DiscountValue / 100),
                    };
                }
            }
            else
            {
                var item = flightBookingContext.FlightSchedule.Where(x => x.FlightScheduledId == flightid).FirstOrDefault();
                if (item != null)
                {
                    model = new DiscountModel
                    {
                        price = item.TicketCost
                    };
                }
                return await Task.FromResult(model);
            }
            return await Task.FromResult(model);
        }

            
    
}
}
