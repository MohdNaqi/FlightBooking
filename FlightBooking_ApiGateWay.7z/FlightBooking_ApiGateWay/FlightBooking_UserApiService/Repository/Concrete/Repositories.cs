﻿using FlightBooking_UserApiService.Entity;

using FlightBooking_UserApiService.Repository.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking_UserApiService.Repository.Concrete
{
    public class Repositories : IRepositories
    {
        public Repositories()
        {
            this.flightBookingContext = new FlightBookingContext();
        }
        public FlightBookingContext flightBookingContext { get; private set; }
        public void Dispose()
        {
            GC.SuppressFinalize("");
        }
    }
}
